<?php
    require'connect.php';
    if(isset($_POST['username'])){
        $username=$_POST['username'];
        $password=$_POST['password'];
        $inserted =mysqli_query(
            $connection,
            "INSERT INTO customer VALUES ('$username','$password')");

    }
 ?>