<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "website";
$connection = mysqli_connect($servername,$username,$password,$db_name);
if(!$connection){
    die("connection failed:" . mysqli_connect_error());
}
echo"connected successfully";
?>
