
<?php
error_reporting(E_ALL);
session_start();
require'connect.php';
if(isset($_POST['username'])){
$username=$_POST['username'];
$password=$_POST['password'];
$sql = "SELECT*FROM customer WHERE username = '$username'";
$result = mysqli_query($connection,$sql);
$row=mysqli_fetch_assoc($result);
if($row){
$usernamedb = $row['username'];
$passworddb = $row['password'];

    
if(($username==$usernamedb)&&($password==$passworddb)){
    $_SESSION['username']=$username;
    echo"Login successful";
    }else{
        echo"Login Failed";
    }}
    else{echo"unsuccessful attempt";
    }}
?>
